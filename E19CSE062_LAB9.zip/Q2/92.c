#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

#define MAX 5
#define MAX_THREAD 6

int a[] = {1,2,3,4,5};
int sum[1] = {0};
int part1 = 0, part2 = 0;
int f[5] = {0};

void* sum_array(void* arg) {
	int thread_part = part1++;
	for(int i=thread_part * (MAX/1);i<(thread_part + 1)*(MAX/1);i++)
		sum[thread_part] = sum[thread_part] + a[i];
	printf("The average of the given array is: %d\n", sum[thread_part]/MAX);
} 

int fact(int n){
	if(n==0 || n==1)
		return 1;
	else 
		return (n)*fact(n-1);
}

void *factorial(void *p) {
	int thread_part = part2++;
	for(int i=thread_part * (MAX/5);i<(thread_part + 1)*(MAX/5);i++)
		f[thread_part] = fact(a[i]);
		printf("Factorial of part %d is: %d\n",part2, f[thread_part]);
	pthread_exit(0);
}

int main() {
	pthread_t threads[MAX_THREAD];
	pthread_create(&threads[5], NULL, sum_array, (void*)NULL);
	pthread_join(threads[5], NULL);
	
	for(int i=0;i<MAX_THREAD-1;i++)
		pthread_create(&threads[i], NULL, factorial, (void*)NULL);
		
	for(int i=0;i<MAX_THREAD-1;i++)
		pthread_join(threads[i], NULL);
	return 0;
		
}
