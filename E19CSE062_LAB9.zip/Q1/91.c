#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

#define MAX 12
#define MAX_THREAD 4

int a[] = {1,1,1,1,2,2,2,2,3,3,3,3};
int sum[4] = {0};
int part = 0;

void* sum_array(void* arg) {
	int thread_part = part++;
	for(int i=thread_part * (MAX/4);i<(thread_part + 1)*(MAX/4);i++)
		sum[thread_part] = sum[thread_part] + a[i];
	printf("\nThe summation of the part %d is: %d", part, sum[thread_part]);
} 

int main() {
	pthread_t threads[MAX_THREAD];
	for(int i=0;i<MAX_THREAD;i++)
		pthread_create(&threads[i], NULL, sum_array, (void*)NULL);
		
	for(int i=0;i<MAX_THREAD;i++)
		pthread_join(threads[i], NULL);
	
	int total_sum = 0;
	for(int i=0;i<MAX_THREAD;i++)
		total_sum += sum[i];
		
	printf("\nSum is: %d\n", total_sum);
	return 0;
		
}
